Pagefind 1.5.2 compiled Help search: corresponding source

This archive accompanies the two precompiled Pagefind WASM search components
served by Vectory Help. Individual source files retain their original licenses.
pagefind_microjson 0.1.4 is GPL-3.0-only; its full text is also in COPYING.
The complete upstream Pagefind source tree and all 21 registry packages in its
WASM lockfile are included. The pagefind_web workspace package is the 22nd.
The matching Snowball 3.0.0 development-revision generator and preferred .sbl
algorithm sources accompany the generated Pagefind stem Rust source, with
their original BSD notice. This is an immutable revision after the 3.0.0 tag;
the tagged release itself did not regenerate the exact packaged Rust.
The five npm runtime packages embedded in the precompiled search UI are also
included in ui-vendor/, pinned to the upstream UI package-lock integrity.
SOURCE-MANIFEST.json records the exact HTTPS inputs and file hashes.

Upstream commit: a2e9f40ef326f9a7926247695df25981a6f3ef4b
Source: https://github.com/Pagefind/pagefind/tree/a2e9f40ef326f9a7926247695df25981a6f3ef4b

These instructions are optional for developers inspecting/modifying search.
Normal Vectory installation uses prebuilt kits and requires no compiler.

Compile the English and language-neutral Rust WASM modules

Use a Rust toolchain compatible with the pinned source and install its
wasm32-unknown-unknown target. Both commands below were verified in an isolated
Rust 1.94.0 container with network access disabled. A compiler/target is not
included. Registry sources are vendored;
Cargo runs offline after the compiler/target have been provisioned.

  cd upstream/pagefind_web
  cargo build --locked --offline --release --target wasm32-unknown-unknown --features en
  cp target/wasm32-unknown-unknown/release/pagefind_web.wasm ../../pagefind.en.wasm
  cargo build --locked --offline --release --target wasm32-unknown-unknown --no-default-features
  cp target/wasm32-unknown-unknown/release/pagefind_web.wasm ../../pagefind.unknown.wasm

The upstream release additionally applies wasm-bindgen and wasm-opt, then
compresses/packages the modules for Pagefind. The complete build scripts and
GitHub release workflow are in upstream/justfile, upstream/.github/workflows/
and upstream/.cargo/. Read those for its release packaging commands and tool
versions. Compiler/optimizer choices can change bytes. A successful source
build is not a claim of byte-for-byte equivalence to the upstream precompiled
artifacts whose hashes are separately recorded in Vectory's public manifest.

Regenerate the stem algorithms (optional)

The packaged stem crate already contains generated Rust, so the Cargo build
above does not require this step. To modify preferred algorithm definitions,
use the supplied Snowball 3.0.0 development source at snowball/ (immutable
commit 988b5ae3fff9db34cc978c8ddd3b84f83ef5ef58). Its algorithms/english.sbl and
compiler/runtime sources are included along with COPYING. A C compiler and
make build the Snowball generator; the upstream Pagefind regeneration helper
also uses Node.js. Run from the archive root:

  make -C snowball
  node upstream/pagefind_stem/build.js

The included generator was compiled with make/cc inside an isolated container
with network disabled. It regenerated English Rust byte-for-byte identical
to the checksum-pinned pagefind_stem crate, and its three Rust runtime files
also matched. Generated English Rust SHA-256:
e83bb65144434954728488c5bd9f796f23a7d6829609db5b4f1adaed5c924a90

Read upstream/pagefind_stem/build.js before regenerating and reviewing the
result. The separately checksum-pinned registry crate in vendor/ is the exact
published compile input; regenerating upstream/ does not overwrite vendor/.
To compile your regenerated stem instead, explicitly replace the vendored
crate and update Cargo's source checksums/lockfile as part of your changes.

This source is provided with the permissions in its respective license texts;
it is not a substitute for a legal assessment of a particular redistribution.
