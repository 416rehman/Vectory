# Changelog

<!--
    Add changes to the Unreleased section during development.
    Do not change this header — the GitHub action that releases
    this project will edit this file and add the version header for you.
    The Unreleased block will also be used for the GitHub release notes.
-->

## Unreleased

* `v1.5.0` was meant to 2x indexing performance, which it does on macOS and Windows. On Linux, with the published musl build, it actually _halves_ the indexing performance. This release subs in jemalloc on Linux musl builds to fix the musl allocator thrashing, and performance now achieves the 2x `v1.4.0` claim.
* Further improved deterministic index filenames between indexes (PR #1104 — thanks @gissimo !).
* Cleaned up a wasm-bindgen deprecation warning popping up in the browser console.

## v1.5.1 (April 8, 2026)

Crate release only. Fixes busted 1.5.0 deployment of the pagefind crate to crates.io.

## v1.5.0 (April 6, 2026)

Hey! This is a big one. Pagefind 1.5.0 has been fermenting for a while, and addresses a _lot_ of long-standing issues and feature requests. This release brings an entirely new search UI built on web components, major improvements to search relevance and ranking, diacritics support, automatic CJK segmentation, Web Worker search, notably smaller indexes, and a much faster indexing binary. Enormous thanks to everyone who contributed features and fixes, as well as to everyone who tested the beta releases and provided feedback ❤️ - @bglw

If you only read this far, I should mention up front: The existing Default UI and Modular UI remain available and supported for now, so you can upgrade your sites to Pagefind v1.5.0 without migrating to the Component UI.

### Pagefind Component UI

Pagefind ships a brand new UI system built entirely on web components. The Component UI gives you searchboxes, modals, result lists, and filter controls as composable `<pagefind-*>` elements that you can mix, match, and style with CSS variables.

The Component UI is available as vendored files in your `/pagefind/` output directory, or as [an npm package](https://www.npmjs.com/package/@pagefind/component-ui) to install and import. 

The best way to get a feel for the new components is on the [📘 Pagefind Component UI](https://pagefind.app/docs/search-ui/#modal-search) page of the docs, where interactive examples of various components are shown.

Extra goodies with the Component UI:

* Greatly improved accessibility over the Default UI
* Keyboard navigation through search results
* Configurable keyboard shortcuts (thanks @miketheman !)
* Full custom templates for rendering results and placeholders
* Exported types for Component UI npm consumers (thanks @vanruesc !)
* Support for multiple scoped Pagefind instances on one page
* A range of CSS variables available for light-touch customization (thanks @miketheman for some of these!)
* Improved RTL and locale-specific rendering

### Search Relevance, and Searching Metadata

Pagefind now searches metadata by default! Importantly, this means it now searches the _title_ metadata. Matches in titles are now taken into account, and search results are _very_ hard to shake from prime positions if all (or much) of the title matches the search query.

You can configure the weight of any metadata field. See [📘 Configuring Metadata Weights](https://pagefind.app/docs/ranking/#configuring-metadata-weights) to change the title boost or apply custom weights to your own metadata fields.

Beyond metadata searching, a _bunch_ of weird and wonderful ranking bugs were resolved:

  - Metadata-only matches now return results. Previously, if a page matched the search query only in its metadata (e.g. the title) but not in the body content, it would be missed. These pages now correctly appear in results.
  - Word splitting and indexing was revisited to properly handle diacritics, stemming, and compound words together. This fixes a broad set of edge cases where compound word parts weren't indexed correctly.
  - Loading index chunks now correctly uses stemmed terms. This was a discrepancy in how chunks were identified, and could cause some hard to pin down issues where the wrong chunk would be loaded for a search term, leaving you with no (or fewer) results.
  - A couple of pathways left you with only the first matching chunk loaded, which would also give you fewer results. Words that straddle multiple chunks now behave better.
  - Fancy-pants unicode characters in words could _really_ mess up the chunk loading, which has been fixed.

### Diacritics Support

We finally properly support matching across diacritics. You can now find your cafés without remembering how to type é.

By default, exact diacritic matches are preferred. So if you're searching "cafe", pages with "cafe" will rank higher than pages with "café". Getting this relevance right by default was the final piece of the puzzle for shipping this, which is why it took a while to land. See [📘 Configuring Diacritic Similarity](https://pagefind.app/docs/ranking/#configuring-diacritic-similarity) to adjust how this plays out on your site.

If you need strict matching, set `exactDiacritics: true` to disable normalization entirely — "cafe" will only match "cafe", and "café" will only match "café". [📘 Exact Diacritics](https://pagefind.app/docs/search-config/#exact-diacritics)

### Multilingual Improvements

Thanks browsers! Pagefind now taps into [Intl.Segmenter](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Intl/Segmenter) to chop search queries in CJK (Chinese, Japanese, Korean) non-whitespace-delimited languages. This was already done during indexing by Pagefind, but users searching still had to delimit their queries. Now searching "这是一段简单的测试文本" searches for the words "这", "是", "一段", "简单", "的", "测试", and "文本", which is also how that sentence was indexed.

We also updated the underlying stemming library (thanks @uded !) which brings stemming support for Polish and Estonian (and Esperanto, if anyone is out there indexing some `lang="eo"` pages). The Snowball upgrade also improves stemming quality across many already-supported languages.

### Indexing Performance

The indexing binary (the one you install through npx or your wrapper of choice) is now both smaller (so, faster to download) and faster to run, by quite a lot on both fronts. On some sites, indexing is more than twice as fast. Thanks to @zmre for much of this!

### Search Performance

Pagefind's search now runs in a Web Worker automatically. This doesn't make the search faster, per se, but it dramatically improves perceived performance on large websites by keeping the main thread responsive. If Web Workers are unavailable, it falls back to the main thread automatically.

Plus: Some low-hanging fruit was picked off, and Pagefind's index chunks are now ~45% smaller thanks to delta-encoding page numbers and word locations.

### New Search Options

* `metaCacheTag` — Allows you to configure the cache-busting tag on the metadata file (which is fetched fresh on every page load). For offline/PWA scenarios where assets need to be served with service workers, this can now be overridden.
* `plain_excerpt` — Search results and sub-results now include a `plain_excerpt` field containing the excerpt text without highlight mark tags, for those who want to handle highlighting themselves (or don't want it at all).
* `matchedMetaFields` — Search results now include a `matchedMetaFields` field listing which metadata fields matched the search query.
* `includeCharacters` is now available in the Node and Python wrapper APIs.

### UI Translations

* Added Greek (el) translations. (PR #1019 — thanks @Yoda-Soda !)
* Improved Chinese Traditional (zh-TW) translations. (PR #990 —thanks @510208 !)
* Improved German (de) translations. (PR #953 —thanks @randomguy-2650 !)
* Added translations for new Component UI strings across all existing languages.

### Other bits and bobs

* Fixed relative image URLs (e.g. `./image.png`) breaking when displayed in search results. (PR #1087)
* Fixed Python x86_64 macOS wheel being incorrectly tagged as `arm64`. (PR #950 — thanks @lioman !)
* Fixed Python wheel tags being written in compressed form. (PR #989 — thanks @ichard26 !)
* Excluded the vendor directory from the main `pagefind` PyPI package. (PR #991)
* Migrated Python wrapper build tooling from Poetry to uv. (PR #934 — thanks @SKalt !)
* Fixed subresult URLs ignoring page meta URL overrides. (PR #1076)
* Fixed subresult highlight mark color. (PR #1024)
* Index chunk fetches are now throttled to avoid overwhelming the network on large sites. (PR #1071)
* Added Windows ARM64 (`aarch64-pc-windows-msvc`) as a supported platform. (PR #1079)
* For crate consumers: Moved `actix-web` and related serving dependencies behind a `serve` feature flag (PR #1023)

### Looking Forward

The Component UI is the new recommended way to add search to your site, and future UI work will focus there. The Default UI and Modular UI are sticking around for now, but the Component UI is where new features will land first.

Thanks again to everyone who contributed to this release!

## v1.5.0-beta.2 (April 3, 2026)

Changes since v1.5.0-beta.1:

- New: Greek translations
- Core refactor to speed up indexing
- Improved type exports for the component UI
- Better keybind configuration for searchbox and modal
- Fixed closing the modal with Esc when the input is focused
- Improved a11y and usability of keyboard navigation in the searchbox when results are loading
- Moved some crate dependencies behind a serve feature flag for crate consumers
- Upgraded the stemming library (Snowball), introducing Polish and Estonian stemming
- Exposed more CSS variables for customizing component UI styling
- Some misc. UI tidy-ups

v1.5.0 will follow in a few days.

## v1.5.0-beta.1 (January 11, 2026)

Hey! This is a big one, so I thought we'd give a beta release a try. This release addresses a lot of long-standing issues and feature requests, alongside delivering an entirely new search UI.

### Pagefind Component UI
This is the main reason for a beta release here. Writing a new ground-up UI system for Pagefind has been a big job, and I would love to get some more eyes on it before we send it out into the world on its stable release.

It's so large, in fact, that it has its own documentation site! If you're itching to see what it looks like, check out https://ui.pagefind.app/ for modals and searchboxes and custom web components and more!

The Component UI is available as vendored files in your `/pagefind/` output directory, or it's available as [an npm package](https://www.npmjs.com/package/@pagefind/component-ui) to install and import.

One big request, for anybody reading this who has or wants to contribute translations, is to go look over the files changed in [PR 1005](https://github.com/Pagefind/pagefind/pull/1005/files). As part of this new UI, we have a new set of translation strings. Thankfully these could mostly be inferred from existing ones, but overall they need reviews from fluent speakers. ❤️

### Search Relevance, and Searching Metadata
Pagefind now searches metadata! Yes, all metadata. By default. Importantly, this means it now searches the _title_ metadata. Matches in titles are now taken into account, and search results are _very_ hard to shake from prime positions if all (or much) of the title matches the search query.

This is also something you can configure! See [📘 Configuring Metadata Weights](https://unreleased.pagefind.app/docs/ranking/#configuring-metadata-weights) for how to change this title boost, or apply it to any and all metadata fields of your choosing.

Alongside that, a _bunch_ of weird and wonderful ranking bugs were resolved. I'll write more in the final release notes, but [PR 1003](https://github.com/Pagefind/pagefind/pull/1003) goes into great detail on the various improvements that make searches better across the board. Plus [PR 996](https://github.com/Pagefind/pagefind/pull/996) covers some of the chunk loading bugs that could also cause corner cases with searches.

### Diacritics Support
We finally properly support matching across diacritics. You can now find your cafés without remembering how to type é!

This is, yet again, something you can configure. By default, exact diacritic matches are preferred. So if you're searching "cafe", pages with "cafe" will rank higher than pages with "café". Getting this relevance right by default was the final piece of the puzzle for shipping this, which is why it took a while to land. See [📘 Configuring Diacritic Similarity](https://unreleased.pagefind.app/docs/ranking/#configuring-diacritic-similarity) to adjust how this plays out on your site.

### Multilingual Improvements
Thanks browsers! Pagefind now taps into [Intl.Segmenter](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Intl/Segmenter) to chop search queries in CJK (Chinese, Japanese, Korean) non-whitespace-delimited languages. This was already done during indexing by Pagefind, but users searching still had to delimit their queries. Now searching "这是一段简单的测试文本" searches for the words "这", "是", "一段", "简单", "的", "测试", and "文本", which is also how that sentence was indexed.

### Performance!
Pagefind's search now runs in a Web Worker automatically. This doesn't make the search faster, per se, but it dramatically improves perceived performance on large websites by keeping the main thread responsive.

If Web Workers are unavailable, it falls back to the main thread automatically.

### More Performance!
Some low-hanging fruit was picked off, and Pagefind's index chunks are now ~45% smaller. The indexing binary (the one you install through npx or your wrapper of choice) is now both smaller (so, faster to download) and faster to run, at least on my macOS machine.

### Phew

Most of these things are pretty solid, and the new Component UI is the most in flux. I don't expect it to change much, but be aware nonetheless that some things might change before it stabilises in 1.5.0.

I would love your feedback! Please jump into the GitHub discussion for this release and highlight any issues. This will simmer happily, depending on feedback, for a week or three, so there's room for changes.

If you haven't used a beta release before, simply:

```bash
# if you run via npx, sub out `pagefind` for `pagefind@beta`
npx pagefind@beta
# or, if you have it as a dependency:
npm i pagefind@beta
# or, if you use the python distribution:
pip install --pre pagefind
# or, via cargo:
cargo install pagefind --version 1.5.0-beta1
```

Or download the correct binary from this GitHub Release page.

Hope to hear from you!

## v1.4.0 (September 1, 2025)

### Core Features & Improvements
* Added the "Include Characters" option to allow indexing of specific special characters.
  * See [📘 Indexing Special Characters](https://pagefind.app/docs/indexing/#indexing-special-characters).
* Reduced filesizes for the Pagefind WebAssembly modules.
* Added FreeBSD as a supported platform (PR #813 — thanks @nguthiru !)
* Fixed an issue where matches in compound words could be ranked with zero weight. (PR #806 — thanks @teamdandelion !)

### Pagefind Playground
* Added the Pagefind Playground
  * Optionally hosted as part of your site, the playground gives you a deeper look into how results are calculated.
  * Check out the playground for the Pagefind docs at https://pagefind.app/pagefind/playground/
  * See [📘 Pagefind Playground](https://pagefind.app/docs/playground/) to configure and view the playground for your own site.

### Modular UI Features & Improvements
* Added option to hide images on result templates in the Modular UI (PR #874 — thanks @HannesOberreiter !)
* Added a data attribute for result count on the filter pills. (PR #827 — thanks @cmahnke !)

### Default UI Features & Improvements
* Added title attribute to the default UI search input for improved accessibility (PR #798 — thanks @rdela !)

### UI Translations
* Added Thai (th) translations (PR #801 — thanks @Phon1209 !)
* Added Thai segmenter support when indexing (PR #807 — thanks @anonymaew !)
* Added Basque (eu) translations (PR #826 — thanks @erral !)
* Added Norwegian Bokmål (nb) and Norwegian Nynorsk (nn) translations (PR #878 — thanks @altinnadmin !)
* Added Burmese (my) translations (PR #768 — thanks @harrymkt !)

### Everything Else
* Added a development `justfile`, and improved CONTRIBUTING.md (hint hint)
* The Pagefind JavaScript should support running in Node.js a bit better (PR #828 — thanks @justsml !)

### Looking Forward
👋 from @bglw — I thought I'd add a new section to these release notes talking about what's next.

The biggest item on my list is to improve the relevance of the Pagefind search results. With the current setup, you can tweak enough settings to get decent results for a given site, but it needs to better meet the goal of working more-than-good-enough out of the box.

The second-biggest item is to fill out the Modular UI and transition the default Pagefind experience to use that. This has been pending for a long time, and will be a much better base for those who wish to customize their search more than the Default UI currently allows.

Releases also now trigger a GitHub Discussion to be created, so please drop any general thoughts, comments, or feedback there 🙂

## v1.3.0 (December 18, 2024)

### Core Features & Improvements
* Added `--quiet` and `--silent` flags when running the Pagefind CLI, which reduce the logging output to only warnings or only errors respectively.
* Stabilized the [Pagefind Rust library](https://docs.rs/pagefind/latest/pagefind/).
  * Thanks to @cdxker for leading this in #751 ❤️
  * This library interface has feature parity with the Node and Python indexing APIs, and is a great solution for integrating Pagefind indexing into any Rust-based tooling.

### Default UI Features & Improvements
* Added a `data-pagefind-ui-meta` attribute to the metadata tags on search results in the Default UI, allowing them to be targeted with CSS.
  * For example, a tag on a result containing `Date: April 19, 2024` will now have `data-pagefind-ui-meta="date"`.

### Fixes & Tweaks
* Fixed an issue where inline metadata would incorrectly render with html-escaped characters.
  * Specifically, tagging metadata inline with `data-pagefind-meta="phrase:this &lt; that` would index the literal `&lt;` rather than a `<` character.
  * This bug didn't occur when using `data-pagefind-meta` to capture the content of an element.
* Fixed an issue where matches in compound words could (sometimes) be ranked lower than intended.
  * Specifically, for example, matching just the `Cannon` in `CloudCannon` may have ranked the word incorrectly.
* Fixed an issue where fragment hashes would change between every Pagefind build.
  * Now, if an HTML page has not changed between two Pagefind indexes, the fragment filename will not change.
  * This saves you from having to re-upload all fragment files after every Pagefind build.

## v1.2.0 (November 6, 2024)

### Core Features & Improvements
* Added Python bindings for indexing sites with Pagefind. This has feature parity with the Node/npx binary wrapper for running Pagefind, as well as feature parity with the NodeJS Indexing API for Pagefind.
  * Enormous thanks to @SKalt for implementing this in #672 ❤️
  * For documentation, see [📘 Installation > Running via Python](https://pagefind.app/docs/installation/#running-via-python), and [📘 Using the Python API](https://pagefind.app/docs/py-api/).

### UI Translations
* Fixed Catalan translations (PR #718 — thanks @danurbanowicz !).
* *️⃣ Added Persian translations (PR #690 — thanks @YektaDev !).
* *️⃣ Added Hebrew translations (PR #453 — thanks @nirtamir2 !).
* *️⃣ Added Arabic translations (PR #533 — thanks @jermanuts !).

*️⃣ : These languages are the first right-to-left languages in the translation set.
Please open any issues if improvements can be made to the Pagefind UI libraries when rendered for these RTL languages.

## v1.1.1 (September 3, 2024)

### Fixes & Tweaks
* Fixes an issue where internal anchor and weight tokens would leak when captured in meta or filter attributes.
* Improves segmentation for extended languages (PR #600 — thanks @hamano !).
* Improves Pagefind's processing of "index.html" URLs (PR #604 — thanks @dscho !).
* Fixes some instances of incorrect types in the Pagefind NodeJS API (PRs #642 & #655 — thanks @vanyauhalin & SKalt !).

### UI Translations
* Added Swahili translations

### Security
* Fix potential DOM clobbering when initializing Pagefind

## v1.1.0 (April 2, 2024)

### Core Features & Improvements
* Improved Pagefind's core result ranking algorithm to align with [BM25](https://en.wikipedia.org/wiki/Okapi_BM25). For existing sites, this will change the ordering of search results, and should provide better relevance for search results by default.
* Added the abitity to configure Pagefind's ranking algorithm.
  * Certain categories of site (i.e. reference documentation) can benefit from tweaks to the way pages are ranked. To support this, a set of ranking parameters are now configurable. Enormous thanks to @dscho for kicking off this work in #534 ❤️
  * See [📘 Customize ranking](https://pagefind.app/docs/ranking/) to read up on the new ranking parameters.

### Default UI Features & Improvements
* Added an `autofocus` setting to the Default UI. The default remains off. See [📘 UI > Autofocus](https://pagefind.app/docs/ui/#autofocus). Thanks to @vanbroup for #514 ❤️
* Added an `openFilters` setting to the Default UI. See [📘 UI > Open filters](https://pagefind.app/docs/ui/#open-filters). Thanks to @vanbroup for #579 ❤️
* Added a `sort` setting to the Default UI. See [📘 UI > Sort](https://pagefind.app/docs/ui/#sort).
* Added a `triggerFilters` function to the Default UI.
  * The existing `triggerSearch` function has also been documented. See [📘 UI > Programmatically controlling the Pagefind UI](https://pagefind.app/docs/ui-usage/#programmatically-controlling-the-pagefind-ui).

### Fixes & Tweaks
* Fixed a bug where the `forceLanguage` setting would not take priority when using the NodeJS Indexing API.
* Fixed a bug where zero-width spaces in the source content could cause errors in search excerpts.

### UI Translations
* Added Ukrainian translations (PR #523 — thanks @vladdnepr !).
* Added Romanian translations (PR #541 — thanks @mateesville93 !).
* Added Czech translations (PR #543 — thanks @dallyh !).
* Added Korean translations (PR #583 — thanks @seokho-son !).
* Improved Japanese translations (PR #560 — thanks @hamano !).

## v1.0.4 (November 16, 2023)

### Features & Improvements
* Added highlighting support to Pagefind. Massive thanks to @Jothsa for pushing this across the line in #425! 🎉
  * See [📘 Highlighting search terms](https://pagefind.app/docs/highlighting/) for documentation on how to enable this new feature.
* Added a page size option to the Default UI. See [📘 UI Configuration > Page size](https://pagefind.app/docs/ui/#page-size).
* Added a `destroy()` function to the Pagefind JS API, allowing for a total re-initialization. See [📘 Re-initializing the search API](https://pagefind.app/docs/api/#re-initializing-the-search-api).
* Added a `destroy()` function to the Pagefind Default UI, allowing for a total re-initialization. See [📘 Re-initializing the Pagefind UI](https://pagefind.app/docs/ui-usage/#re-initializing-the-pagefind-ui).

### Fixes & Tweaks
* Fixed a bug, resulting in a (very) large improvement to the NodeJS Indexing API performance (~100x).
* Fixed HTML entities being rendered escaped in metadata, filters, and custom page titles.
* Fixed a bug where `debouncedSearch` returns `null` if any options object is passed to it.
* Fixed a bug where a fully-qualified URL set via the NodeJS indexing API would be broken when returned as a search result.
* Fixed Pagefind's reporting of really fast indexing times (previously logged as slower than reality) — thanks to @danpls in #448.
* Fixed extracting sub-results when headings contain non-ascii text (especially RTL languages).

### UI Translations

* Added Māori translations (PR #436 — thanks @Yoda-Soda !).
* Added Croatian translations (PR #440 — thanks @diomed !).
* Added Hungarian translations (PR #451 — thanks @adamlaki !).
* Added Bengali translations (PR #454 — thanks @marufmax !).
* Added Vietnamese translations (PR #467 — thanks @AREA44 !).
* Added Polish translations (PR #495 — thanks @KredensKuchenny !).
* Added Danish translations (PR #501 — thanks @jonassmedegaard !).

## v1.0.3 (September 16, 2023)

Hopefully the last hotfix for now — bugfixes only important for sites indexing Japanese or Chinese pages.

* Fixes a bug indexing ja/zh language pages containing weighting or element IDs
* Removes eager warnings being logged to the browser console if bundling the UI JavaScript files
* Adds a `.close()` function to the Pagefind NodeJS API, to help clean up the process when it is no longer required

## v1.0.2 (September 14, 2023)

* Fixes a bug when indexing some non-breaking spaces on ja/zh language pages in extended mode

## v1.0.1 (September 14, 2023)

Hotfix for Pagefind v1.0.0, restoring default-on support for multilingual word segmentation, and helping resolve packaging issues with new dependencies.

* Fixed the `pagefind` npm wrapper to use the `pagefind_extended` release, as documented.
* Changed `microjson` git dependency to a `pagefind_microjson` crate dependency (for now) — #421 .

## v1.0.0 (September 13, 2023)

Pagefind 1.0 is here! This release has been many months in the making, and we're thrilled to be bringing some great new features and improvements.

This release also marks a point in time for Pagefind's stability and maturity. Thanks to everyone who has helped out with contributions and feedback in the last year, we're now more confident than ever that Pagefind is a perfect fit with nearly any static website, staying performant and lean even as your site scales.

### ‼️ Breaking Changes

This 1.0 release includes one breaking change, and some notable non-breaking behavioral changes.
A full writeup of these changes and their effects exists in the [📘 Migrating to Pagefind 1.0](https://pagefind.app/docs/v1-migration/) guide on Pagefind's website.

* **BREAKING**:
  * PREVIOUS: By default, Pagefind 0.x outputs files to a `_pagefind` in your site.
  * NEW: By default, Pagefind 1.x outputs files to a `pagefind` in your site.
  * More details on this change can be found in the [[📘 migration guide](https://pagefind.app/docs/v1-migration/#new-default-output-location)].

### ⚠️ Behavioral Changes

* Changes to CLI options [[📘 migration guide](https://pagefind.app/docs/v1-migration/#renamed-cli-options)]:
  * The `source` option has been renamed to `site`.
  * The `bundle-dir` option has been renamed to `output-subdir`.
  * A new `output-path` option has been added.
* Search indexing and ranking changes will cause result lists to differ from 0.x [[📘 migration guide](https://pagefind.app/docs/v1-migration/#changes-to-search-relevancy-and-ranking)].
* The JS API initializes Pagefind at a different stage of execution [[📘 migration guide](https://pagefind.app/docs/v1-migration/#changes-to-the-pagefind-js-api-initialization)].

### 🎉 New Features!

#### ✨ Content weighting ✨

Pagefind now supports configurable weighting for regions of content, which will be used when ranking results and generating excerpts.
Headings are automatically weighted higher, and custom weights can be inserted anywhere in your page.

See [📘 Weighting sections of the page higher or lower](https://pagefind.app/docs/weighting/) for documentation.

#### ✨ Sub results ✨

Pagefind now tracks headings and IDs when indexing your site. This can be used to show multiple results per page when searching your site, with direct links to the closest parent anchor.

See [📘 Showing multiple results per page](https://pagefind.app/docs/sub-results/) for documentation.

#### ✨ NodeJS indexing API ✨

The `pagefind` package on npm can now be imported as a library into a NodeJS script, giving you programmatic control over indexing content from both disk and memory.

This feature is very open ended — be it integrating Pagefind into a static site generator, or indexing non-static and non-HTML content, we're excited to see what people come up with! Open a [discussion](https://github.com/CloudCannon/pagefind/discussions) on GitHub if you build anything unique that you would like to share!

See [📘 Indexing content using the NodeJS API](https://pagefind.app/docs/node-api/) for documentation.

#### ✨ Greatly improved ranking and relevancy ✨

Pagefind now takes inverse document frequency into account, meaning words that are unique across your site will rank higher than common words.
The ranking algorithm has also been improved across the board, which should result in better search relevance by default.

We're always looking to improve search relevance further, so open an issue on GitHub if you have any examples of searches that don't hit the mark.

#### ✨ Indexing compound words and code ✨

Pagefind now better supports indexing various forms of compound words and code, meaning `<MyComponent data-pagefind-body>` will now match searches for **my**, **component**, **data**, **pagefind**, and **body**.

### 🎉 More Features & Improvements

* Pagefind now returns results for a prefix of the search word if there would otherwise be zero results:
  * e.g. if searching for `bandwidth` would return zero results, you might get results for `band` or `ban`.
* Pagefind can now search for emoji 🎉🚀✨.
* Do you filter more than you search? For those using the JS API directly, Pagefind now supports complex compound filtering:
  * [📘 Using compound filters](https://pagefind.app/docs/js-api-filtering/#using-compound-filters).
* Pagefind is now smarter at generating excerpts, returning the most dense region of search hits on the page.
  * Excerpt calculation also integrates with the new weighting feature, and will favor areas of the page with higher weighted words.
* The `pagefind` npm package no longer downloads binaries from a GitHub release, and instead has platform-specific dependencies that download only the relevant binary from npm.
  * This improves the installation speed of Pagefind through npm/npx, and also removes the need for any postinstall script making the entire process more reliable.
* The Default UI now supports being passed an HTMLElement directly, as an alternative to a selector (PR #331 — thanks @stefanprobst).
* The length of excerpts that Pagefind generates can now be customized:
  * [📘 Default UI excerptLength](https://pagefind.app/docs/ui/#excerpt-length).
  * [📘 JS API excerptLength](https://pagefind.app/docs/search-config/#excerpt-length).

### Fixes & Tweaks

* **CLI**: Fixed an issue where multiple `data-pagefind-body` tags on a page would conflict if one was nested deeper than the other.
* **CLI**: Fixed builds for some Windows systems that were missing vcruntime.
* **JS API**: A new `pagefind.init()` function has been added, meaning `pagefind.options()` can be called _before_ loading assets, allowing you to change the path to load files from.
* **JS API**: Performance searching very large sites for short terms should be improved.
* **JS API**: Passing an empty array for a filter value now behaves as if the filter was not supplied, instead of returning zero results.
* **Default UI**: Don't reset the browser-provided outlines when resetting UI styles.
* **Default UI**: Fixed an issue where titles containing HTML elements were not correctly escaped.
* **Default UI**: Improved the search input on mobile devices (PR #368 — thanks @valtlai !).
* **Default UI**: Fixed an issue where some UI strings would appear in English instead of the translated language.

### UI Translations

* Added Indonesian translations (PR #273 — thanks @nixentric !).
* Added Serbian translations (PR #285 — thanks @DigitLib !).
* Added Italian translations (PR #323 — thanks @apjanco !).
* Added Hindi translations (PR #324 — thanks @Amitind !).
* Added Finnish translations (PR #366 — thanks @valtlai !).
* Added Turkish translations (PR #395 — thanks @taylanbildik !).
* Added Tamil translations (PR #402 — thanks @sanjaiyan-dev !).

## v0.12.0 (March 1, 2023)

> Note: v0.12.0 will likely be the last feature release before an upcoming v1.0.0 that will contain a small handful of breaking changes. See the [v1.0.0 milestone](https://github.com/CloudCannon/pagefind/milestone/4) on GitHub for details and updates.

### Features & Improvements
* **CLI**: Added a "Keep Index URL" setting. (PR #233 — thanks @kenpetti-toasttab !). See [Pagefind CLI > Keep Index URL](https://pagefind.app/docs/config-options/#keep-index-url)
* **JS API**: Added a `totalFilters` object to the search response, containing the total matches for the search term under each filter
* **JS API**: Added an `unfilteredResultCount` key to the search response, containing the total matches for the search term if no filters were applied

### Fixes & Tweaks
* **CLI**: Stopped warning when encountering `data-pagefind-ignore="true"` instead of `data-pagefind-ignore`
* **Search**: Fixed merging filters from multiple indexes
* **Default UI**: Fixed filters sticking open once search input has been focused
* **Default UI**: Fixed the search input clearing when hitting the `Enter` key
* **Search / Default UI**: Fixed HTML tags in Pagefind excerpts not being escaped. The `content` key remains unprocessed

## v0.11.0 (February 16, 2023)

### Features & Improvements
* **CLI**: Improved `npx` wrapper compatibility on Windows, thanks @tylermercer!
* **JS API**: Added a `debouncedSearch` function to the JS API. See [Pagefind JS API > Debounced search](https://pagefind.app/docs/api/#debounced-search)
* **Default UI**: Added a "Clear" button to the search input
* **Default UI**: Clear the search input on an `Esc` keypress
* **Default UI**: Added UI translations for Swedish, thanks @mntzrr!
* **Default UI**: Added a `processTerm` hook that can normalize the search query. See [Pagefind UI > Process term](https://pagefind.app/docs/ui/#process-result)
* **Default UI**: Added a `Clear` button to the search input
* **Default UI**: Added functionality to clear the search input when `Esc` is pressed while the input is focused
* **Default UI**: Published UI to npm under [@pagefind/default-ui](https://www.npmjs.com/package/@pagefind/default-ui), as an alternative to using the files output by the Pagefind CLI

### Fixes & Tweaks
* **Default UI**: Fixed a syntax error in the CSS

### Prelease: Modular UI
* Work is underway on a new "Modular UI" that will live alongside the current "Default UI". Full support and documentation will be provided in a future release — the prerelease version can be found on npm under [@pagefind/modular-ui](https://www.npmjs.com/package/@pagefind/modular-ui)
  * As this package is still under development, some of the configuration may change in a future release. Make sure to pin your Pagefind versions for any production site relying on the Modular UI.

## v0.10.7 (January 19, 2023)

* Avoid using bsdtar in the release flow, as that will sometimes create sparse tar files that some packages cannot decompress. (Fixes lumeland/lume#362)

## v0.10.6 (December 18, 2022)

* Adds UI translations for Galician, Català & Spanish, thanks @pvillaverde!
* Fixes Pagefind failing on Safari due to an unsupported regex

## v0.10.5 (December 14, 2022)

* Fixed an issue where merging an index from a fully-qualified domain name would mangle the mapped URLs

## v0.10.4 (December 6, 2022)

* Fixed a corner case where a `data-pagefind-body` tag wouldn't be honored on pages with DOM nodes outside the main `html` element

## v0.10.3 (December 2, 2022)

* Fixed the Windows deployment target

## v0.10.2 (November 24, 2022)

* Updated only deployment targets:
  * Pagefind now distributes an `aarch64-apple-darwin` build for M1 macOS machines
    * This will provide a speed benefit on these machines by skipping the Rosetta 2 emulation
  * Pagefind now distributes an `aarch64-unknown-linux-musl` build for ARM Linux machines
    * Useful for ARM Docker images on M1 macOS
* Updated the npm/npx wrapper to reflect the newly available binaries

## v0.10.1 (November 23, 2022)

* Changed HTML parsing to a non-strict mode that will no longer error when encountering parsing ambiguities
* Updated the npm wrapper to respect an exit code returned from the main Pagefind binary

## v0.10.0 (November 15, 2022)

### Features & Improvements
* Added the ability to exclude custom selectors via Pagefind config. See the [exclude selectors](/docs/config-options/#exclude-selectors) documentation

### Fixes & Tweaks
* Fixed an issue where running a multi-site search through Pagefind UI wouldn't wait for all search indexes to be ready

## v0.9.3 (November 7, 2022)

* When the search term `null` is passed, Pagefind returns all results with filters applied.
  * In the case of a `null` search and an empty filters object, Pagefind would previously return **zero** results.
  * Pagefind will now return **all** results in this case.

## v0.9.2 (November 6, 2022)

* Pagefind can now automatically read gzipped HTML files as its source
* Pagefind's automatic metadata now falls back to the `title` of a page if there is no `h1` element
* Fixed a couple of inconsistent url formatting issues on Windows

## v0.9.1 (October 26, 2022)

* Fix Windows release assets once more

## v0.9.0 (October 26, 2022)

### Important Changes
* Removed `<header>` from the list of elements that Pagefind automatically ignores
  * If this element contains content you do not want to be indexed, you will now need to add `data-pagefind-ignore`

### Features & Improvements
* Added sorting functionality to Pagefind, see the [Sorting documentation](https://pagefind.app/docs/sorts/) and the [JS API Sorting usage](https://pagefind.app/docs/api/#sorting-results)
* Added the functionality to filter an index without searching, by passing `null` as the search query
* Added support for custom Pagefind UI strings, see [Using custom Pagefind UI strings](https://pagefind.app/docs/ui/#using-custom-pagefind-ui-strings)
* Added a default debounce to the user input for Pagefind UI, and a corresponding `debounceTimeoutMs` option, see [Debounce user input](https://pagefind.app/docs/ui/#debounce-user-input)
  * Many thanks to @dprothero for the contribution! 💝
* Added a hook to process results before showing them in Pagefind UI, see the [processResult documentation](https://pagefind.app/docs/ui/#process-result)

### Fixes & Tweaks
* Fixed running Pagefind on Windows via the npx wrapper
* Pagefind now throws an error if a completely empty index is produced for whatever reason
* Fixed a bug where having exactly one known and one unknown language would drop the known language pages
* Fixed issue where `two<br/>words` would be indexed as `twowords` rather than the correct `two words`
* Added `<style>` to the list of elements that Pagefind automatically ignores
* Fixed the Pagefind UI `showEmptyFilters` option to work as expected
* Fixed issue where adding a filter to a search with zero results would return all results for the filter
* Fixed uncommon bug around chunk boundaries
  * For example: If your first search index chunk started with the word `hello` and you searched for `h`, Pagefind would previously not load the `hello` chunk and would instead return zero results.

## v0.8.1 (September 12, 2022)

* Pagefind now gracefully skips pages that fail HTML parsing, and provides more context when these errors are hit.

## v0.8.0 (August 23, 2022)

### Important Changes
* For those using the JS API directly, the `pagefind.options` function is now async. This will not break current usage, but using newer options may require `await pagefind.options({ ... })` for them to be applied

### Features & Improvements
* Added Multisite search support, allowing you to search multiple indexes from one Pagefind instance. See the new [Multisite documentation](https://pagefind.app/docs/multisite/) for more information
* Added a preload function to the JS search API, allowing you to warm Pagefind up before a search, or while the user is typing. See the [Preload documentation](https://pagefind.app/docs/api/#preloading-search-terms) for more information
* Added a `timings` object to the JS search API response

### Fixes & Tweaks
* Passing a non-existent filter to the search function would previously be silently ignored. This will now return zero results
* Setting your baseURL to an external domain such as `https://example.com` would previously be prepended with a `/`. This is now handled correctly and will link off-site
* Pagefind would previously index search entities such as `&quot;` without unescaping them. This is now fixed and these characters will be skipped
* Searching for only punctuation would previously return all pages currently loaded into the Pagefind index. This will now return zero results
* Fixed a regression causing searches for hyphenated-phrases to return zero results
* Fixed Pagefind UI failing to match complex language codes such as `zh-hans-tw` to less complex translation files such as `zh-tw`

## v0.7.1 (August 13, 2022)

* Added French translations for Pagefind UI — thanks [@nfriedli](https://github.com/nfriedli)!
* Fixed standard & extended release archives attached to GitHub releases to be correctly assigned

## v0.7.0 (August 12, 2022)

### Features & Improvements

* Multilingual support
  * Pagefind now works out of the box for multilingual sites
  * Pagefind UI is now translated into `af`, `de`, `en`, `ja`, `no`, `pt`, `ru`, & `zh`
  * See the [multilingual documentation](https://pagefind.app/docs/multilingual/) for more information on this feature release
  * This release adds a `pagefind_extended` binary release, which is larger than the `pagefind` release but includes support for indexing Chinese and Japanese languages
    * `pagefind_extended` is now the default when running `npx pagefind`. The smaller `pagefind` release is still available via the [GitHub Release](https://github.com/CloudCannon/pagefind/releases) attachments

### Fixes & Tweaks

* Improved Pagefind logging and added a `--verbose` flag with extra information
* Added warnings when Pagefind encounters pages without outer `<html>` elements
* Added a console warning when Pagefind detects that a cached `pagefind.js` file was loaded alongside a search index from a newer release

## v0.6.1 (August 5, 2022)

* Oops — fixes the npx wrapper on Windows

## v0.6.0 (August 5, 2022)

### Features & Improvements

* Added prebuilt Windows binaries
  * This adds Windows support for running Pagefind via `npx pagefind`
  * Windows binaries can also be downloaded via the [GitHub Releases](https://github.com/CloudCannon/pagefind/releases)

## v0.5.3 (July 30, 2022)

* Tēnā koutou katoa — Fixed an issue where Pagefind could not search for words containing some special characters.

## v0.5.2 (July 29, 2022)

* Support Apple Silicon Macs (via Rosetta 2)

## v0.5.1 (July 29, 2022)

* Fixed a form submission error in Pagefind UI causing trouble for some content security policies
* Fixed a visual quirk in the Pagefind UI filters on Safari

## v0.5.0 (July 26, 2022)

### Features & Improvements

* The glob that Pagefind uses for finding files to index can now be configured. See [Config > Glob](https://pagefind.app/docs/config-options/#glob)
* Added a `data-pagefind-ignore="all"` option that does not process filters or metadata within the target element. See [Indexing > Removing individual elements from the index](https://pagefind.app/docs/indexing/#removing-individual-elements-from-the-index)
* Added a `data-pagefind-default-meta` attribute that can provide fallback values for metadata that could not be found on the page. See [Metadata > Defining default metadata](https://pagefind.app/docs/metadata/#defining-default-metadata)
* UI: Pagefind UI will now check for a `url` key in a page's metadata that should be used over the generated URL. See [UI > Overriding the URL of a result](https://pagefind.app/docs/ui/#overriding-the-url-of-a-result)
* UI: Added a configuration option for hiding images from the Pagefind UI. See [UI > Show images](https://pagefind.app/docs/ui/#show-images)
* UI: Added a configuration option to hide filter values that have no available results given the search query and existing filters. See [UI > Show empty filters](https://pagefind.app/docs/ui/#show-empty-filters)
* UI: The Pagefind UI filter panel will now default to expanded if there are sufficiently few filters

### Fixes & Tweaks

* Server gzip support
  * Pagefind implements its own gzip handling, but would fail in the rare case that a server detected the gzipped files and served them such that a browser would decompress them. Pagefind will now identify that these files have already been decompressed rather than error.
* UI: HTML entity improvements
  * Fixed the remaining elements in the Pagefind UI that did not correctly render HTML entities.
* UI: Filter state improvements
  * Previously, deleting a search term would reset the selected filter values and the open filter groups. This state is now preserved when the search input is empty.
* UI: The Pagefind UI JS and CSS files are now correctly minified

## v0.4.1 (July 7, 2022)

### Fixes & Tweaks

* Hash fragment contents using the entire file, to prevent stale content
* Use the image_alt correctly in Pagefind UI

## v0.4.0 (July 6, 2022)

### Features & Improvements

* An automatic `image_alt` metadata value will be included when returning an automatic `image` metadata value. See [Metadata > Default metadata](https://pagefind.app/docs/metadata/#default-metadata)
* Multiple filter and metadata keys set can be set per element. See [Metadata > Defining multiple keys](https://pagefind.app/docs/metadata/#defining-multiple-metadata-keys-on-a-single-element)
* A root selector can now be configured to further restrict Pagefind indexing. See [Config > Root selector](https://pagefind.app/docs/config-options/#root-selector)
* If re-running Pagefind over an output directory, existing hashed files will be reused if present, which will improve hot build speeds for large sites.
* Added latest version to the header of the [documentation](https://pagefind.app).

### Fixes & Tweaks

* Added `<template>` elements to the ignored text index list
* Multiple exact matches on a page will no longer be returned as separate results

## v0.3.2 (July 4, 2022)

Tidied up the search API output to remove some not-yet-implemented fields.

## v0.3.1 (July 4, 2022)

Changed images in Pagefind UI to contain rather than cover. Relevant CSS variables have changed slightly.

## v0.3.0 (July 2, 2022)

Added a `--serve` option to the Pagefind CLI that will host the site on a local development server after building the search index.

## v0.2.0 (July 1, 2022)

The first stable 0.x release of Pagefind.
