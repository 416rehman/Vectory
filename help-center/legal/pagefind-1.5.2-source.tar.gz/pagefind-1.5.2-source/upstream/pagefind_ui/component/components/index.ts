export { getInstanceManager, configureInstance } from "./instance-manager";

import { registerFunction } from "adequate-little-templates";

registerFunction("resolveUrl", (url, pageUrl) => {
  const s = String(url ?? "");
  if (!s || /^[a-z][a-z0-9+.-]*:/i.test(s) || /^\/\//.test(s) || s.startsWith("/")) return s;
  try {
    return new URL(s, new URL(String(pageUrl ?? "/"), "https://p")).pathname;
  } catch {
    return s;
  }
});

import "./pagefind-config";
import "./pagefind-input";
import "./pagefind-summary";
import "./pagefind-results";
import "./pagefind-filter-pane";
import "./pagefind-filter-dropdown";
import "./pagefind-modal";
import "./pagefind-modal-trigger";
import "./pagefind-modal-header";
import "./pagefind-modal-body";
import "./pagefind-modal-footer";
import "./pagefind-keyboard-hints";
import "./pagefind-searchbox";

export { PagefindConfig } from "./pagefind-config";
export { PagefindInput } from "./pagefind-input";
export { PagefindSummary } from "./pagefind-summary";
export { PagefindResults } from "./pagefind-results";
export { PagefindFilterPane } from "./pagefind-filter-pane";
export { PagefindFilterDropdown } from "./pagefind-filter-dropdown";
export { PagefindModal } from "./pagefind-modal";
export { PagefindModalTrigger } from "./pagefind-modal-trigger";
export { PagefindModalHeader } from "./pagefind-modal-header";
export { PagefindModalBody } from "./pagefind-modal-body";
export { PagefindModalFooter } from "./pagefind-modal-footer";
export { PagefindKeyboardHints } from "./pagefind-keyboard-hints";
export { PagefindSearchbox } from "./pagefind-searchbox";

export { PagefindElement } from "./base-element";
